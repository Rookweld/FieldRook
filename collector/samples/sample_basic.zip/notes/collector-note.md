# Collector note (sample)

Technician visited front desk; user reports Windows Update stuck at 0%.
Package collected read-only with consent; no command lines included.
